package practise1;

public class DuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1="Automation is future of Tester";
		
	}

}
