package programmpractise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FindAllLinks {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
