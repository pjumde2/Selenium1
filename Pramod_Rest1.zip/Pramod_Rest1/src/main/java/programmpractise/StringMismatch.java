package programmpractise;

import java.util.Scanner;

public class StringMismatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String S;
		String reverse="";
		int count=0;
		
		Scanner scan=new Scanner(System.in);
		S= scan.nextLine();
		System.out.println("String is:"+S);

	}

}
