package programmpractise;

public class duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] str=""Hellow word", " Hellow word My name is Sujit"".split(",");

        String [] str1=str.split(" ");  " "

int count=1;

for(int i=0; i<str1.length();i++)
{
for(int j=i+1;j<str1.length();j++)
{
     if(str1[i].equals(str1.[j])

{
str1[j]==" ";
count++;


}

if(str1[i]!=" "
{
  Sysout.out.println(str1[i]+"====="+count)
}

count=1;

}
}



}




	}

}
