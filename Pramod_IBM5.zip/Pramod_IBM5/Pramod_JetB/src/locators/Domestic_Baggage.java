package locators;

public class Domestic_Baggage {
	
	public static String Launchwci="html/body/div[2]/p[2]/a[1]";
	public static String FirstName="//*[@id='firstName']";
	public static String LastName="//*[@id='lastName']";
	public static String DepartureCity="//*[@id='departureCity']";
	public static String Conf_code="//*[@id='recordLocator']";
	public static String Find_flight="//*[@id='continueButton']";
	public static String Travel_info="//*[@id='borderTable']/div[3]/span[1]/div/div/span[2]/label";
	public static String Choose_Traveller="//*[@id='continueCustomHook']";
	public static String Hazar_Material="//*[@id='answer1']";
	public static String Hazar_Continue="//*[@id='continueButton']";
	public static String Change_Seat="//*[@id='borderTable']/div[2]/span/div/div[3]/span[2]/a";
	public static String ChangeSeat_Skip="//*[@id='skipCustomButton']";
	public static String Extras_Skip="//*[@id='skipButton']";
	public static String Checking_Bags="//*[@id='yesBagsButton']";
	public static String Checked_Bag="//div[@id='innerTable']/span[2]/div/div[1]/span[4]";
	public static String Checked_Bag_Continue="//*[@id='continueButton']";
	public static String Card_Type="//*[@id='creditCardType']";
	public static String Cardholder_Name="//*[@id='paymentTxnInfo.ccName']";
	public static String Card_Number="//*[@id='paymentTxnInfo.ccNumber']";
	public static String CVV="//*[@id='paymentTxnInfo.cvv']";
	public static String Expiry_Month="//*[@id='expiryMonth']";
	public static String Expiry_Year="//*[@id='expiryYear']";
	public static String Ass_Device="//*[@id='passengerBagUpdates0.hasAssistive1']";
	public static String Count_Ass_Device="//div[@id='innerTable']/span[2]/div/div[3]/span[4]";

}

