package locators;



public class Login {

	public static String username = "fullnameFromPopUp";
	public static String password= "password";
	public static String button="submit";
}
