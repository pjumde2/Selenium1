package test8;

import java.util.Scanner;

public class Revword {

	public static void main(String[] args) {
		
		String reverse="";
		
		System.out.println("Please enter string: ");
		
		Scanner scan=new Scanner(System.in);
		String [] str=scan.nextLine().split(" ");
		
		for(int i=str.length-1;i>=0;i--)
		{
			reverse=reverse+str[i]+" ";
		}
		
		System.out.println("Reverse string is: "+reverse);

	}

}
