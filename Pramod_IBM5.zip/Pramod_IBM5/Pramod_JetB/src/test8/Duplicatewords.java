package test8;

public class Duplicatewords {

	public static void main(String[] args) {
		
		
		String str[]="abc,bca,mna,abc,mna".split(",");
		int count=1,total=0;
		
		for(int i=0;i<str.length;i++)
		{
			for(int j=i+1;j<str.length;j++)
			{
				if(str[i].equals(str[j]))
				{
					count++;
					str[j]="0";
							
				}
			}
			if(str[i]!="0")
			{
				System.out.println(str[i]+"-------------"+count);
				total=total+count;
				count=1;
			}
		}
		
		System.out.println("Total words: "+total);
		
	}

}
