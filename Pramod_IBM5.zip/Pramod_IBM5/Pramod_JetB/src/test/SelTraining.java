package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SelTraining {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.gecko.driver", "C:\\Selenium Jars\\Selenium 3.4\\geckodriver-v0.16.0-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///C:/Users/IBM_ADMIN/Desktop/HTML/Test1.html");
		
		
		driver.findElement(By.id("FirstName")).sendKeys("Ramesh");
		driver.findElement(By.id("LastName")).sendKeys("Bhagat");
		driver.findElement(By.id("address")).sendKeys("Datta Mandir Road, Wakad, Pune");
		Select dropdown = new Select(driver.findElement(By.id("stateId")));
		dropdown.selectByIndex(1);
		Select dropdown1 = new Select(driver.findElement(By.id("countryid")));
		dropdown1.selectByIndex(1);

	}

}
