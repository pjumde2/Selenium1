package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GVST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//System.setProperty("webdriver.chrome.driver", 
		//		"C://chromedriver.exe");
		//WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.gecko.driver", "C:\\Selenium Jars\\Selenium 3.4\\geckodriver-v0.16.0-win64\\geckodriver.exe");
		WebDriver	driver = new FirefoxDriver();
	//	WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///C:/Users/IBM_ADMIN/Desktop/test.html");
		driver.findElement(By.name("FirstName")).sendKeys("ASD");
		driver.findElement(By.name("LastName")).sendKeys("Last");
		//driver.findElement(By.id("element_button_1")).click();
		
			}

}
