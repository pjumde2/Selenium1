package test;

public interface Intr {
	public void m1();
}
