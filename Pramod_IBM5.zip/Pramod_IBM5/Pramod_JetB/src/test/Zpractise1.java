package test;

import java.util.Scanner;

public class Zpractise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num,i,j;
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter number: ");
		num=scan.nextInt();
		
		for(i=1;i<=num;i++)
		{
			for(j=0;j<=(num-1);j++)
			{
				System.out.print(+num);
				num--;
			}
			
		}
	

	}

}
