package test;

import java.util.Scanner;

public class LengthString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		String str=sc.nextLine();
		int count=0;
		char ar[]=str.toCharArray();
		for(char c : ar){
		count++;
		}
		System.out.println(count);
		}
	}


