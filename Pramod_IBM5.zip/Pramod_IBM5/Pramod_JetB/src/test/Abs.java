package test;

public abstract class Abs {
    public void m1() {
        System.out.println("Abs.m1()");
    }
    // public abstract void m1();
}
