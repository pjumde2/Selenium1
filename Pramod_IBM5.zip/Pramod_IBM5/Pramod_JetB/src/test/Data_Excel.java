package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Data_Excel {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File file = new File("C:\\Users\\IBM_ADMIN\\Desktop\\HTML\\Data.xls");
		FileInputStream inputstream= new FileInputStream(file);
		HSSFWorkbook wb=new HSSFWorkbook(inputstream);
		HSSFSheet sheet=wb.getSheet("Sheet1");
		int rows=sheet.getPhysicalNumberOfRows();
		System.out.println("Rows are: "+rows);
		HSSFRow Row=sheet.getRow(0);
		int column=Row.getPhysicalNumberOfCells();
		System.out.println("Columns are: "+column);
		
		
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<column;j++)
			{
				Row=sheet.getRow(i);
				System.out.println(Row.getCell(j).getStringCellValue());
				
			}
		}
		
		
		
		

	}

}
