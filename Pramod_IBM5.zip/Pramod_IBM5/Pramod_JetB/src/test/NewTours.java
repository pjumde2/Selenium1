package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NewTours {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.gecko.driver", "C:\\Selenium Jars\\Selenium 3.4\\geckodriver-v0.16.0-win64\\geckodriver.exe");
		WebDriver	driver = new FirefoxDriver();
		driver.get("http://newtours.demoaut.com/mercuryregister.php");
		
	/*	driver.findElement(By.name("firstName")).sendKeys("Ramesh");
		driver.findElement(By.name("lastName")).sendKeys("Gulhane");
		driver.findElement(By.name("phone")).sendKeys("0202345677");
		driver.findElement(By.id("userName")).sendKeys("klrt@gmail.com");  */
		
		
		
		
		
		
		
		
		
		

	}

}
