package test2;

import java.util.Scanner;

public class Traingle5 {

	public static void main(String[] args) {
		
		int num,i,j;
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter Number: ");
		
		num=scan.nextInt();
		
		for(i=1;i<=num;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print((i+j)%2);
			}
			System.out.println();
		}

	}

}
