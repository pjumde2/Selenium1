package test2;

public class RevWord {

	public static void main(String[] args) {
		
		String str[]="There is the one".split(" ");
		String finalstr="";
		
		for(int i=str.length-1;i>=0;i--)
		{
			finalstr=finalstr+str[i]+" ";
		}
		System.out.println(finalstr);

	}

}
