package test2;

import java.util.Scanner;

public class Traingle4 {

	public static void main(String[] args) {
		
		int num,c=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Number: ");
		num=scan.nextInt();
		
		loop1: for(int i=1;i<=num;i++)
		{
		loop2: for(int j=1;j<=i;j++)	
		{
			if(c<num)
			{
				c++;
				System.out.print(" "+c);
			}
			else
			{
				break loop1;
			}
		}
		System.out.println();
			
		}

	}

}
