package test2;

import java.util.Scanner;

public class Traingle2 {

	public static void main(String[] args) {
		
		int num,i,j;
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter Number: ");
		
		num=scan.nextInt();
		
		System.out.println(" "+"1");
		
		for(i=1;i<=num;i++)
		{
			for(j=0;j<=i;j++)
			{
				System.out.print(" "+i);
			}
			System.out.println();
		}

	}

}
