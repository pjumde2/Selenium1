package test2;

import java.util.Scanner;

public class Traingle3 {

	public static void main(String[] args) {
		
		int num,i,j;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Number: ");
		num=scan.nextInt();
		
		while(num>0)
		{
			for(j=0;j<num;j++)
			{
				System.out.print(" "+num+" ");
			}
			System.out.println();
			num--;
		}
		

	}

}
