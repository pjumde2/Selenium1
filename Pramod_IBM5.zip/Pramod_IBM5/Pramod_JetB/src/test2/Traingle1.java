package test2;

import java.util.Scanner;

public class Traingle1 {

	public static void main(String[] args) {
		
		int num;
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter Number: ");
		num=scan.nextInt();
		
		for(int i=1;i<=num;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(" "+i);
			}
			System.out.println();
		}

	}

}
