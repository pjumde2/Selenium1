package commonclasses;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import scripts.Domestic_Baggage;

public class index extends Domestic_Baggage{

	public static void SelectOptionwithIndex1(int indexToSelect1) {
		try {
	
//	WebDriverWait wait=new WebDriverWait(driver, 20);

	List<WebElement> optionsToSelect1 = driver.findElements(By.xpath("html/body/div[5]"));
	
	 if(indexToSelect1<=optionsToSelect1.size()) {
        	System.out.println("Trying to select based on index: "+indexToSelect1);
           optionsToSelect1.get(indexToSelect1).click();
           System.out.println("Done1");
        }

	
} catch (NoSuchElementException e) {
	System.out.println(e.getStackTrace());
}
catch (Exception e) {
	System.out.println(e.getStackTrace());
}
	}
	
	public static void SelectOptionwithIndex (int indexToSelect) {
		// TODO Auto-generated method stub
		try {
			//WebElement autoOptions = driver.findElement(By.xpath("//div[6]/ul/li"));
			//wait.until(ExpectedConditions.visibilityOf(autoOptions));
			//WebDriverWait wait=new WebDriverWait(driver, 20);

			List<WebElement> optionsToSelect = driver.findElements(By.xpath("html/body/div[6]"));
			/*for(WebElement option : optionsToSelect){
		        if(option.getText().equals(textToSelect)) {
		        	System.out.println("Trying to select: "+textToSelect);
		            option.click();
		            break;
		        }
		    }*/
			//wait.until(ExpectedConditions.visibilityOfAllElements(optionsToSelect));
			 if(indexToSelect<=optionsToSelect.size()) {
		        	System.out.println("Trying to select based on index: "+indexToSelect);
		           optionsToSelect.get(indexToSelect).click();
		           System.out.println("Done");
		        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
		
		
	}
	
	public static void SelectOptionwithIndexCard (int indexToSelect2) {
		// TODO Auto-generated method stub
		try {
			//WebElement autoOptions = driver.findElement(By.xpath("//div[6]/ul/li"));
			//wait.until(ExpectedConditions.visibilityOf(autoOptions));
		//	WebDriverWait wait=new WebDriverWait(driver, 20);

			List<WebElement> optionsToSelect2 = driver.findElements(By.xpath("html/body/div[5]"));
			if(indexToSelect2<=optionsToSelect2.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect2);
	           optionsToSelect2.get(indexToSelect2).click();
	           System.out.println("Done1");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
		
		
	}
	
	
	public static void SelectOptionwithExpiryMonth (int indexToSelect3) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect3 = driver.findElements(By.xpath("html/body/div[6]"));
			if(indexToSelect3<=optionsToSelect3.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect3);
	           optionsToSelect3.get(indexToSelect3).click();
	           System.out.println("Done3");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	
	public static void SelectOptionwithExpiryYear (int indexToSelect4) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect4 = driver.findElements(By.xpath("html/body/div[7]"));
			if(indexToSelect4<=optionsToSelect4.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect4);
	           optionsToSelect4.get(indexToSelect4).click();
	           System.out.println("Done4");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	public static void SelectOptionwithBirthYear (int indexToSelect5) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect5 = driver.findElements(By.xpath("html/body/div[5]"));
			if(indexToSelect5<=optionsToSelect5.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect5);
	           optionsToSelect5.get(indexToSelect5).click();
	           System.out.println("Done5");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithBirthMonth (int indexToSelect6) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect6 = driver.findElements(By.xpath("html/body/div[6]"));
			if(indexToSelect6<=optionsToSelect6.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect6);
	           optionsToSelect6.get(indexToSelect6).click();
	           System.out.println("Done6");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithBirthDay (int indexToSelect7) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect7 = driver.findElements(By.xpath("html/body/div[7]"));
			if(indexToSelect7<=optionsToSelect7.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect7);
	           optionsToSelect7.get(indexToSelect7).click();
	           System.out.println("Done7");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithPassNationality (int indexToSelect8) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect8 = driver.findElements(By.xpath("html/body/div[8]"));
			if(indexToSelect8<=optionsToSelect8.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect8);
	           optionsToSelect8.get(indexToSelect8).click();
	           System.out.println("Done8");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithIssueCountry (int indexToSelect9) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect9 = driver.findElements(By.xpath("html/body/div[9]"));
			if(indexToSelect9<=optionsToSelect9.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect9);
	           optionsToSelect9.get(indexToSelect9).click();
	           System.out.println("Done9");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	
	public static void SelectOptionwithPassExpiryYear (int indexToSelect10) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect10 = driver.findElements(By.xpath("html/body/div[5]"));
			if(indexToSelect10<=optionsToSelect10.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect10);
	           optionsToSelect10.get(indexToSelect10).click();
	           System.out.println("Done10");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithPassExpiryMonth (int indexToSelect11) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect11 = driver.findElements(By.xpath("html/body/div[5]"));
			if(indexToSelect11<=optionsToSelect11.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect11);
	           optionsToSelect11.get(indexToSelect11).click();
	           System.out.println("Done11");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithPassExpiryDay (int indexToSelect12) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect12 = driver.findElements(By.xpath("html/body/div[6]"));
			if(indexToSelect12<=optionsToSelect12.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect12);
	           optionsToSelect12.get(indexToSelect12).click();
	           System.out.println("Done12");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithEmerCountry (int indexToSelect13) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect13 = driver.findElements(By.xpath("html/body/div[3]"));
			if(indexToSelect13<=optionsToSelect13.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect13);
	           optionsToSelect13.get(indexToSelect13).click();
	           System.out.println("Done13");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithVisaType (int indexToSelect14) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect14 = driver.findElements(By.xpath("html/body/div[3]"));
			if(indexToSelect14<=optionsToSelect14.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect14);
	           optionsToSelect14.get(indexToSelect14).click();
	           System.out.println("Done14");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	public static void SelectOptionwithVisaExpYear (int indexToSelect15) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect15 = driver.findElements(By.xpath("html/body/div[4]"));
			if(indexToSelect15<=optionsToSelect15.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect15);
	           optionsToSelect15.get(indexToSelect15).click();
	           System.out.println("Done15");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	public static void SelectOptionwithVisaExpMonth (int indexToSelect16) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect16 = driver.findElements(By.xpath("html/body/div[5]"));
			if(indexToSelect16<=optionsToSelect16.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect16);
	           optionsToSelect16.get(indexToSelect16).click();
	           System.out.println("Done16");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
	
	public static void SelectOptionwithVisaExpDay (int indexToSelect17) {
		// TODO Auto-generated method stub
		try {
			
			List<WebElement> optionsToSelect17 = driver.findElements(By.xpath("html/body/div[6]"));
			if(indexToSelect17<=optionsToSelect17.size()) {
	        	System.out.println("Trying to select based on index: "+indexToSelect17);
	           optionsToSelect17.get(indexToSelect17).click();
	           System.out.println("Done17");
	        }
		
			
		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
				
	}
	
}



