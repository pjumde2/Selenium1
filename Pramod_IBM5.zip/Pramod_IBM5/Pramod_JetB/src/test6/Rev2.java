package test6;

import java.util.Scanner;

public class Rev2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String original,reverse="";
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Please enter string: ");
		
		original=scan.nextLine();
		
		for(int i=original.length()-1;i>=0;i--)
		{
			reverse=reverse+original.charAt(i);
			
		}
		
		System.out.println("Reverse string is: "+reverse);

	}

}
