package test6;

public class WordsCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Java is very good language";
		
		int count=1;
		
		for(int i=0;i<=s.length()-1;i++)
		{
			if((s.charAt(i)==' ') && (s.charAt(i+1)!=' '))
			{
				count++;
				
			}
		}
		
		System.out.println("Number of words in String: "+count);

	}

}
