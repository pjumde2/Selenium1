package test6;

public class DuplicateWord {

	public static void main(String[] args) {
		
		
		String [] str="abc,bca,mna,abc,mna,jkl,bca,klp".split(",");
		
		int count=1;
		
		for(int i=0;i<=str.length-1;i++)
		{
			for(int j=i+1;j<=str.length-1;j++)
			{
				if(str[i].equals(str[j]))
				{
					count++;
					str[j]="0";
				}
			}
			if(str[i]!="0")
			{
				System.out.println(str[i]+"-----"+count);
				count=1;
				
			}
		}

	}

}
