package test6;

import java.util.Scanner;

public class StringLength {

	public static void main(String[] args) {
		
		
		int count=0;
		System.out.println("Please enter String:");
		
		Scanner scan=new Scanner (System.in);
		
		String ch=scan.nextLine();
		
		char a[]=ch.toCharArray();
		
				
		for(char chh:a)
		{
			count++;
		}
		System.out.println("Entered string length:"+count);

	}

}
