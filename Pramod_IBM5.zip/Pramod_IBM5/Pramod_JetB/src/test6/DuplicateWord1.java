package test6;

public class DuplicateWord1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] str= "abc,bca,mna,abc,mna,bca,klp".split(",");
		int count=1;
		
		for(int i=0;i<=str.length-1;i++)
		{
			for(int j=i+1;j<=str.length-1;j++)
			{
				if(str[i].equals(str[j]))
				{
					count++;
					str[j]="0";
				}
			}
			if(str[i]!="0")
			{
				System.out.println(str[i]+"-------"+count);
				count=1;
				
			}
		}

	}

}
