package test6;

import java.util.Scanner;

public class Rev3 {

	public static void main(String[] args) {
				
		String Original,Reverse="";
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter string: ");
		Original=scan.nextLine();
		
		for(int i=Original.length()-1;i>=0;i--)
		{
			Reverse=Reverse+Original.charAt(i);
		}
		
		System.out.println("Reverse String is: "+Reverse);

	}

}
