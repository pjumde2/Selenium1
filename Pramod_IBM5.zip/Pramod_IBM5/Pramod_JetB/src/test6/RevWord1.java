package test6;

public class RevWord1 {

	public static void main(String[] args) {
		
		
		String str []="Java is Language good".split(" ");
		String finalstr="";
		
		for(int i=str.length-1;i>=0;i--)
		{
			finalstr=finalstr+str[i]+" ";
		}
		System.out.println("Reverse word is: "+finalstr);

	}

}
