package test4;

public class DuplicateWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] str="abc,bcd,ghj,abc,bcd".split(",");
		int count=1;
		int total = 0;
		
		for(int i=0;i<str.length;i++)
		{
			for(int j=i+1;j<str.length;j++)
			{
				if(str[i].equals(str[j]))
				{
					count++;
					str[j]="0";
				}
			}
			
			if(str[i]!="0")
			{
				System.out.println(str[i]+"---"+count);
				total=total+count;
				count=1;
			}
			
		}
		
		System.out.println("Total words counted: " + total);

	}

}
