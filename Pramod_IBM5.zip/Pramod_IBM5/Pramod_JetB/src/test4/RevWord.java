package test4;

import java.util.Scanner;

public class RevWord {

	public static void main(String[] args) {
		
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter string: ");
		String [] str=scan.nextLine().split(" ");
		
		
		String finalstr="";
		
		for(int i=str.length-1;i>=0;i--)
		{
			finalstr=finalstr+str[i]+" ";
			
		}
		System.out.println(finalstr);

	}

}
