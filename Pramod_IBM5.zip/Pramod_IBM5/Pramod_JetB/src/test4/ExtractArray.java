package test4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExtractArray {

	public static void main(String[] args) {
		
       int[] intarray= {5,3,2,-1,-4,-3};
         
          List<Integer> lowerArray= new ArrayList<>();

        List<Integer> greaterArray= new ArrayList<>();
        
        for (int a : intarray)
        {
        	if(a<0) {
        		lowerArray.add(a);
        	}
        	else
        	{
        		greaterArray.add(a);
        	}
        	
        	
        }
        
        Collections.sort(lowerArray);
        Collections.sort(greaterArray, Collections.reverseOrder());
        
        lowerArray.addAll(greaterArray);
        System.out.println("===="+lowerArray.toString());
        
        

	}

}
