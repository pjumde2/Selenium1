package test4;

import java.util.Scanner;

public class Traingle3 {

	public static void main(String[] args) {
		
		int num,i,j;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Please enter Number: ");
		num=scan.nextInt();
		
		for(i=1;i<=num;i++)
		{
			for(j=0;j<=i;j++)
			{
				System.out.print((i+j)%2);
			}
			System.out.println();
		}

	}

}
