package test4;

public class DuplicateInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] input1 = {2,7,17,19,20,45,56,159,239};
        int[] input2 = {7,12,15,19,22,34,55,150,159};
        int index1=0, index2=0;
       
       while(true)
       {
       if(input1[index1]==input2[index2])
       {
    	   System.out.println(input1[index1]);
    	   index1++;
       }
       else 
    	   if(input1[index1]<input2[index2])
    	   {
    		   index1++;
    	   }
    	   else
    		   index2++;

	}
	}

}
