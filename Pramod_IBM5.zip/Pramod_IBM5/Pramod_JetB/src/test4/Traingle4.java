package test4;

import java.util.Scanner;

public class Traingle4 {

	public static void main(String[] args) {
		
		int num,i,j;
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter Number: ");
		num=scan.nextInt();
		
		while(num>0)
		{
			for(i=0;i<num;i++)
			{
				System.out.print(num);
			}
			num--;
			System.out.println();
		}

	}

}
