package test4;

import java.util.Scanner;

public class StringLenght {

	public static void main(String[] args) {
		
		int count=0;
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter string: ");
		String ch=scan.nextLine();
		char [] a=ch.toCharArray();
		
		for(char c:a)
		{
			count++;
		}
		System.out.println(count);

	}

}
