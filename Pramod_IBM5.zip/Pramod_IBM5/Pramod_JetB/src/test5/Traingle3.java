package test5;

import java.util.Scanner;

public class Traingle3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num,i;
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter number: ");
		num=scan.nextInt();
		
		while(num>0)
		{
			for(i=1;i<=num;i++)
			{
				System.out.print(" "+num+" ");
			}
			num--;
			System.out.println();
		}

	}

}
