package test5;

public class WordCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="welcome to candid java tutorial";
		
		int count=1;
		
		for(int i=0;i<=s.length()-1;i++)
		{
			if((s.charAt(i)==' ') && (s.charAt(i+1)!=' '))
			{
				count++;
				
			}
				
		}
		
		System.out.println("number of word in string: "+count);

	}

}
