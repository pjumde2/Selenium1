package test5;

public class RevWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] str="This is java".split(" ");
		String finalstr="";
		
		for(int i=str.length-1; i>=0;i--)
		{
			finalstr=finalstr+str[i]+" ";
		}
		System.out.println(finalstr);

	}

}
