package test5;

import java.util.Scanner;

public class Revstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String original,reverse="";
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter String: ");
		
		original=scan.nextLine();
		
		for(int i=original.length()-1;i>=0;i--)
		{
			reverse=reverse+original.charAt(i);
			
		}
		System.out.println(reverse);

	}

}
