package test5;

import java.util.Scanner;

public class StringLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter string: ");
		int count=0;
		
		String ch=scan.nextLine();
		char [] a=ch.toCharArray();
		
		for(char chh : a)
		{
			count++;
		}
		System.out.println("Entered String Length: "+count);

	}

}
