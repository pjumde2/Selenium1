package test5;

public class DuplicateWords1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String []  str="abc,bcd,bnm,abc,bcd,klm".split(",");
		int count=1;
		
		for(int i=0;i<str.length;i++)
		{
			for(int j=i+1;j<str.length;j++)
			{
				if(str[i].equals(str[j]))
				{
					count++;
					str[j]="0";
					
				}
			}
			if(str[i]!="0")
			{
				System.out.println(str[i]+"-----"+count);
				count=1;
				
			}
			
		}

	}

}
