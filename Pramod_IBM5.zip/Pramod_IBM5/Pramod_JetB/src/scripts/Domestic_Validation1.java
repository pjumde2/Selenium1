package scripts;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Driver.LaunchApplication;
import Driver.ReadExcel;
import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import commonclasses.index;

public class Domestic_Validation1 extends LaunchApplication{
	
	public static String domestic_validation1(HashMap<String, String> hm)
	{

		try{
			
			System.out.println("You are in Domestic_Validation1");
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="Domestic_Validation1";
			screenshot=screenshot+"_"+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			//driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Launchwci)).click();
			
			// Store the current window handle
			String winHandleBefore = driver.getWindowHandle();

			// Perform the click operation that opens new window

			// Switch to new window opened
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}

			// Perform the actions on new window
			driver.manage().window().maximize();
			Thread.sleep(4000);	
			driver.findElement(By.xpath(locators.Domestic_Baggage.FirstName)).sendKeys(hm.get("First_Name"));
			driver.findElement(By.xpath(locators.Domestic_Baggage.LastName)).sendKeys(hm.get("Last_Name"));
		
			
			
			WebElement textBoxElement = driver.findElement(By.xpath(locators.Domestic_Baggage.DepartureCity));
			textBoxElement.sendKeys(hm.get("Dept_Airport"));
			index d1=new index();
			d1.SelectOptionwithIndex(0);
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Conf_code)).sendKeys(hm.get("Conf_code"));
			driver.findElement(By.xpath(locators.Domestic_Baggage.Find_flight)).click();
			
			
			Thread.sleep(10000);
			driver.findElement(By.xpath(locators.Domestic_Baggage.Choose_Traveller)).click();
			
			Thread.sleep(3000);
			driver.findElement(By.xpath(locators.Domestic_Baggage.Hazar_Material)).click();
			driver.findElement(By.xpath(locators.Domestic_Baggage.Hazar_Continue)).click();
			
			Thread.sleep(13000);
		/*	WebElement textBoxElement1 = driver.findElement(By.xpath("//*[@id='regDocPassportUpdates0.dateOfBirthYear']"));
			textBoxElement1.sendKeys("2017");
			
			
			d1.SelectOptionwithIndex1(0);*/
			
		
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Change_Seat)).click();
			Thread.sleep(9000);
			driver.findElement(By.xpath(locators.Domestic_Baggage.ChangeSeat_Skip)).click();
			Thread.sleep(7000);
			driver.findElement(By.xpath(locators.Domestic_Baggage.Extras_Skip)).click();
			Thread.sleep(7000);
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Checking_Bags)).click();
			Thread.sleep(10000);
			
			int Bags=Integer.valueOf(hm.get("Baggage"));
			
			for(int i=1;i<=Bags;i++)
			{
			driver.findElement(By.xpath(locators.Domestic_Baggage.Checked_Bag)).click();
			}
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Checked_Bag_Continue)).click();
			Thread.sleep(7000);
			
			WebElement CardBoxElement = driver.findElement(By.xpath(locators.Domestic_Baggage.Card_Type));
			CardBoxElement.sendKeys(hm.get("Card_Type"));
			index d2=new index();
			d2.SelectOptionwithIndexCard(0);
			
			driver.findElement(By.xpath(locators.Domestic_Baggage.Cardholder_Name)).sendKeys(hm.get("Cardholder_Name"));
			driver.findElement(By.xpath(locators.Domestic_Baggage.Card_Number)).sendKeys(hm.get("Card_Number"));
			driver.findElement(By.xpath(locators.Domestic_Baggage.CVV)).sendKeys(hm.get("CVV"));
			
			WebElement ExpiryMonthElement = driver.findElement(By.xpath(locators.Domestic_Baggage.Expiry_Month));
			ExpiryMonthElement.sendKeys(hm.get("Expiry_Month"));
			index d3=new index();
			d3.SelectOptionwithExpiryMonth(0);
			
			
			WebElement ExpiryYearElement = driver.findElement(By.xpath(locators.Domestic_Baggage.Expiry_Year));
			ExpiryYearElement.sendKeys(hm.get("Expiry_Year"));
			index d4=new index();
			d4.SelectOptionwithExpiryYear(0);
			driver.findElement(By.xpath("//*[@id='continueCustomHook']")).click();
			Thread.sleep(2000);
							
			ActualResult=driver.findElement(By.xpath("//*[@id='ContentIn']/div/div[12]/div/div/div/div/a")).getText();
			ExpectedResult=hm.get("ExpectedResult");
			
			if(ExpectedResult.contains(ActualResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			
			
			
			
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
		}
		
		return null;
		
	}

}
