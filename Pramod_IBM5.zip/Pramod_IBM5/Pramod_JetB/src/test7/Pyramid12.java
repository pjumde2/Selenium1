package test7;

import java.util.Scanner;

public class Pyramid12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row, count=1;
		
		System.out.println("Please enter number of rows in Pyramid:");
		Scanner scan=new Scanner(System.in);
		
		row=scan.nextInt();
		
		for(int i=row;i>=1;i--)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=count;k++)
			{
				System.out.print(k+" ");
			}
			System.out.println();
			count++;
			
		}

	}

}
