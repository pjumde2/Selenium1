package test7;

import java.util.Scanner;

public class Pyramid5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
       int row;
		
		System.out.println("Please enter number of rows in Pyramid: ");
		
		Scanner scan = new Scanner(System.in);
		row=scan.nextInt();
		int count=row;
		
		for(int i=0;i<row;i++)
		{
			for(int k=1;k<=i*2;k++)
			{
				System.out.print(" ");
			}
			
			for(int j=1;j<=count;j++)
			{
				System.out.print(j+" ");
			}
			
			for(int j=count-1;j>=1;j--)
			{
				System.out.print(j+" ");
			}
			System.out.println();
			count--;
			
		}

	}


}