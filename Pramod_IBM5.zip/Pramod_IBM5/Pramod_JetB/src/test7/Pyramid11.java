package test7;

import java.util.Scanner;

public class Pyramid11 {

	public static void main(String[] args) {
		
		int row,count=1;
		
		System.out.println("Please enter number of rows in Pyramid: ");
		
		Scanner scan=new Scanner(System.in);
		row=scan.nextInt();
		
		for(int i=row;i>0;i--)
			
		{
			for(int k=1;k<=i;k++)
			{
				System.out.print(" ");
			}
			
			for(int j=1;j<=count;j++)
			{
				System.out.print(count+" ");
			}
			System.out.println();
			count++;
		}

	}

}
