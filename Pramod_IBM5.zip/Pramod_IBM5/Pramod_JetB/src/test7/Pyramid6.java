package test7;

import java.util.Scanner;

public class Pyramid6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int row;
			
			System.out.println("Please enter number of rows in Pyramid: ");
			
			Scanner scan = new Scanner(System.in);
			row=scan.nextInt();
			int count=1;
			
			for(int i=row;i>=1;i--)
			{
				for(int k=1;k<=i*2;k++)
				{
					System.out.print(" ");
				}
				
				for(int j=i;j<=row;j++)
				{
					System.out.print(j+" ");
				}
				
				for(int j=row-1;j>=1;j--)
				{
					System.out.print(j+" ");
				}
				System.out.println();
				count++;
				
			}

		}


	}
