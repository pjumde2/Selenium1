package test3;

import java.util.Scanner;

public class Traingle4 {

	public static void main(String[] args) {
		
		
		int num,i,j,c=0;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Please Enter Number: ");
		num=scan.nextInt();
		
		Loop1: for(i=1;i<=num;i++)
		{
			Loop2: for(j=1;j<=i;j++)
			{
				c++;
				System.out.print(c);
			}
		System.out.println();
		
		}

	}

}
