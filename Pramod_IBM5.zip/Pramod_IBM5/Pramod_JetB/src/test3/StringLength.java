package test3;

import java.lang.reflect.Array;
import java.util.Scanner;

public class StringLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter string: ");
		String ch=scan.nextLine();
		char [] ar=ch.toCharArray();
		
		for(char c : ar)
		{
			count++;
		}
		
		System.out.println(count);

	}

}
