package stepDefinition;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;



public class base {
	

	
public static WebDriver driver;
	

	public static WebDriver getDriver()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Sel_Training\\chromedriver_win32\\chromedriver.exe");  
      	
	       // Instantiate a ChromeDriver class.     
	    WebDriver driver=new ChromeDriver();
	    
	    return driver;
	}

}
