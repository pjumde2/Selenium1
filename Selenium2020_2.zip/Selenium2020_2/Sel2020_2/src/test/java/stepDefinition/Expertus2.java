package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.When;

public class Expertus2 {
	public static WebDriver driver;	
	
	@When("^I enter Invalid First and Last name$")
	public void i_enter_Invalid_First_and_Last_name() throws Throwable {
		
		driver=base.getDriver();
		driver.get("http://demo.automationtesting.in/Register.html");
		driver.findElement(By.xpath("//div/input[@placeholder='First Name']")).sendKeys("!@#$%");
		//driver.findElement(By.xpath(OR.getProperty("firstname"))).sendKeys("Amit");
		driver.findElement(By.xpath("//div/input[@placeholder='Last Name']")).sendKeys(")(*&^%$");
	}

	@When("^I enter all valid details$")
	public void i_enter_all_valid_details() throws Throwable {
	    
	}

	@When("^click on Submit button$")
	public void click_on_Submit_button() throws Throwable {
	   
	}

}
