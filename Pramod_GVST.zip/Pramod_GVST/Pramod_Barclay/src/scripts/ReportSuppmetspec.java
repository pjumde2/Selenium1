package scripts;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Driver.LaunchApplication;
import Driver.ReadExcel;
import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;

public class ReportSuppmetspec extends LaunchApplication {
	
	public static String Reportsuppmetspec(HashMap<String, String> hm)
	{

		try{
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="ReportSuppmetspec";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.xpath("//*[@id='element_button_3']")).click();
			driver.findElement(By.xpath("//*[@id='grid_column_6_clsp_anchor']")).click();
			
						
			driver.findElement(By.xpath("//*[@id='element_label_11']")).click();
			
			
			driver.findElement(By.xpath("//div[@id='element_radio_1_ctrl_div']//input[@id='element_radio_1_option_1']")).click();
			
			List<WebElement> listOfLiElements = driver.findElements(By.className("listComponent"));
			for(int i=0; i< listOfLiElements.size(); i++){
				List<WebElement> listOfSpan = listOfLiElements.get(i).findElements(By.cssSelector("*[class$='listElm checkListRow']"));
				for (int j =0; j< listOfSpan.size(); j++){


					if(listOfSpan.get(j).getText().equalsIgnoreCase("UK (Commercial inc worldwide)")){

						listOfSpan.get(j).findElement(By.cssSelector("input:not(:checked)[type='checkbox']")).click();
						
					}
					
					break;
				}				
			}
			
			driver.findElement(By.xpath("//div[@id='element_radio_2_ctrl_div']//input[@id='element_radio_2_option_1']")).click();
				
			List<WebElement> listOfLiElements1 = driver.findElements(By.className("listComponent"));
			for(int i=0; i< listOfLiElements1.size(); i++){
				List<WebElement> listOfSpan1 = listOfLiElements.get(i).findElements(By.cssSelector("*[class$='listElm checkListRow']"));
				for (int j =0; j< listOfSpan1.size(); j++){


					if(listOfSpan1.get(j).getText().equalsIgnoreCase("ABA Chartered Surveyors (Wealth - JSY)")){

						listOfSpan1.get(j).findElement(By.cssSelector("input:not(:checked)[type='checkbox']")).click();
						
					}
					
					break;
				}				
			}
			
			driver.findElement(By.xpath("//*[@id='element_checkbox_1']")).click();
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
			
			File file=new File("C://Users//IBM_ADMIN//Downloads//SupplierSearchMetricsReportContent.xlsx");
			
		     
			ExpectedResult=file.getName().toString();
			ActualResult="SupplierSearchMetricsReportContent.xlsx";
			
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
		
			
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
				
		
	}
		
		return null;
		
	}

}
