package scripts;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import commonclasses.GetLatestFilefromDir;
import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;

import Driver.LaunchApplication;
import Driver.ReadExcel;

public class ReportPannelsummary extends LaunchApplication {

	public static String Reportpannelsummary(HashMap<String, String> hm)
	{

		try{

			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="ReportPannelsummary";
			screenshot=screenshot+TestCaseId;

			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();

			driver.findElement(By.xpath("//*[@id='element_button_3']")).click();
			driver.findElement(By.xpath("//*[@id='grid_column_6_clsp_anchor']")).click();


			driver.findElement(By.xpath("//*[@id='element_label_8']")).click();

			//List RadioButton =  driver.findElements(By.id("element_radio_1_ctrl_div"));
			driver.findElement(By.xpath("//div[@id='element_radio_1_ctrl_div']//input[@id='element_radio_1_option_0']")).click();

			driver.findElement(By.xpath("//div[@id='element_radio_2_ctrl_div']//input[@id='element_radio_2_option_0']")).click();

			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();

			//File file=new File("C://Users//IBM_ADMIN//Downloads//PanelSummaryReportContent.xlsx");


			//ExpectedResult=file.getName().toString();
			ExpectedResult="PanelSummaryReportContent.xlsx";

			File getLatestFile = GetLatestFilefromDir.GetLatestFilefromDirMethod("C://Users//IBM_ADMIN//Downloads//");


			ActualResult = getLatestFile.getName();
			System.out.println("Actual Result is:" +ActualResult);

			if(ActualResult.regionMatches(true, 0, ExpectedResult, 0, 24))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;

				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}

			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}



		}catch(Exception e)

		{
			System.out.println(e.getMessage());


		}

		return null;

	}

	/*private static File getLatestFilefromDir(String path) {
		// TODO Auto-generated method stub

		File dir = new File(path);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;

	}*/

}
